class Sprite:
    """
    Sprite Class
    """
    def __init__(self):
        """
        Initialize a Sprite instance
        """
        pass
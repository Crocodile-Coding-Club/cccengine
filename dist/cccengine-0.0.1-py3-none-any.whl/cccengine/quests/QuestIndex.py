quest_index = {
    "Quest1":{
        "description": "a simple quest for test",
        "category": "story"
    },

    "Quest2":{
        "description": "another simple quest for test",
        "category": "annex"
    }
}
